# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cmsrucio_import']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['cmsrucio-import = cmsrucio_import.main:app']}

setup_kwargs = {
    'name': 'cmsrucio-import',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Rahul Chauhan',
    'author_email': 'rahul.chauhan@cern.ch',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
